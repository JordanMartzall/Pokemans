
public enum Direction {
	RIGHT(), DOWN(), LEFT(), UP();
}
