import java.util.Random;

public class Pokeman {
	String name;
	Attack attack1;
	Attack attack2;
	Attack attack3;
	Attack attack4;
	double maxHealth;
	double currHealth;
	int xloc;
	int yloc;
	Random seed = new Random();
	
	public Pokeman(String name, Attack attack1, Attack attack2, Attack attack3, Attack attack4, double maxHealth, double currHealth) {
		this.name = name;
		this.attack1 = attack1;
		this.attack2 = attack2;
		this.attack3 = attack3;
		this.attack4 = attack4;
		this.maxHealth = maxHealth;
		this.currHealth = currHealth;
		this.xloc = seed.nextInt(1000);
		this.yloc = seed.nextInt(600);
	}
}
