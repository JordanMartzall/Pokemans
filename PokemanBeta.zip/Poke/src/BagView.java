import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class BagView {
	Font arial = new Font(24);
	
	Stage stage;
	Scene scene;
	Group root;
	GraphicsContext gc;
	private int canvasWidth = 1200;
	private int canvasHeight = 700;
	
	// Inventory Button
	Button escape= new Button("Escape");
	Button usePotion = new Button("Use Potion");
	boolean inBag = true;
	boolean potion = false;
	
	
	
	public BagView(Stage stage)	{
		this.stage = stage;
		this.root = new Group();
		this.scene = new Scene(root);
		Canvas canvas = new Canvas(canvasWidth, canvasHeight);
        root.getChildren().addAll(canvas);
        gc = canvas.getGraphicsContext2D();
        gc.setFont(arial);
        
        // Button insertion
        escape.setLayoutX(10);
        escape.setLayoutY(10);
        escape.setPrefSize(100,80);
        escape.setOnAction(value -> { 
        	System.out.println("Pushed Button"); this.inBag = false; });
        
        usePotion.setLayoutX(1100);
        usePotion.setLayoutY(10);
        usePotion.setPrefSize(100,80);
        usePotion.setOnAction(value -> { 
        	System.out.println("Pushed Button"); this.potion = true; });
        
       root.getChildren().add(escape);
       root.getChildren().add(usePotion);
    
       
	}
	
	public void setStage()	{
		stage.setScene(scene);
	}
}
