
public class Attack {
	String name;
	int damage;
	int accuracy; //In effect will be divided by 10
	String effect;
	
	public Attack(String name, int damage, int accuracy, String effect) {
		this.name = name;
		this.damage = damage;
		this.accuracy = accuracy;
		this.effect = effect;
	}
	
	@Override
	public String toString()	{
		return this.name;
	}
}
