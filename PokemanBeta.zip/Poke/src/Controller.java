import javafx.application.Application;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Random;

import javax.jws.WebParam.Mode;

import javafx.animation.AnimationTimer;
import java.util.Collection;


public class Controller extends Application {
	private double time;
	private double pauseTime;
	private View view;
	private Model model;
	private BagView bagView;
	final long startNanoTime = System.nanoTime();
	private boolean needReset = false;
	
//	// Inventory Button
//	Button bag = new Button("Inventory");
//	boolean inBag = false;
	
	public static void main(String[] args) {
		
		launch(args);
		
    }


	@Override
	public void start(Stage stage) throws Exception {
		
		this.view = new View(stage);
		this.model = new Model(900,0);
		this.bagView = new BagView(this.view.stage);
		
		new AnimationTimer() {
			public void handle(long currentNanoTime) 
			{
				time = (System.nanoTime()-startNanoTime)/1e9;
				if (view.inBag == false)	{
					view.setStage();
				}
				else	{
					if (bagView.inBag == false)	{
						view.inBag = false;
					}
					bagView.setStage();
					if (bagView.potion == true)	{
						model.useItem(model.potion, model.player);
					}
				}
				stage.setFullScreenExitHint(""); //gets rid of "press esc to exit message"
				stage.setFullScreen(true);
			
				// Inventory Button
//				Button bag = new Button("Inventory");
//				boolean inBag = false;
//			        bag.setLayoutX(10);
//			        bag.setLayoutY(350);
//			        bag.setPrefSize(100,80);
//			        bag.setOnAction(value -> { 
//			        	System.out.println("Pushed Button"); inBag = true; });
//			       view.root.getChildren().add(bag);
				
				view.scene.addEventHandler(KeyEvent.KEY_PRESSED, (key) ->{
					if(key.getCode() == KeyCode.DOWN)	{
						switch(model.getBattleFlag())	{
						
						case NONE:
							model.setyMod(1);
							model.setxMod(0);	
							break;
						case DURING:
							model.selectAttackInt(2, model.player);
							break;
						default: 
							break;
						}
					}

					else if(key.getCode() == KeyCode.UP)	{
						switch(model.getBattleFlag())	{
						
						case NONE:
							model.setyMod(-1);
							model.setxMod(0);
							break;
						case DURING:
							model.selectAttackInt(1, model.player);
							break;
						default:
							break;
						}
					}	

					else if(key.getCode() == KeyCode.LEFT)	{
						switch(model.getBattleFlag())	{
						
						case NONE:
							model.setxMod(-1);
							model.setyMod(0);
							break;
						case DURING:
							model.selectAttackInt(3, model.player);
							break;
						default:
							break;
						}
					}

					else if(key.getCode() == KeyCode.RIGHT)	{
						switch(model.getBattleFlag())	{
						
						case NONE:
							model.setxMod(1);
							model.setyMod(0);
							break;
						case DURING:
							model.selectAttackInt(4, model.player);
							break;
						default:
							break;
						}
					}	
					
					else if (key.getCode() == KeyCode.ENTER)	{
						switch (model.getBattleFlag())	{
						
						case DURING:
							model.useAttack(model.getSelectedAttack(), model.player, model.currEnemy);
							break;
							
//						case END:
//							model.playerX = 50;
//							model.progressBattle();
						default:
							break;
							 
						}
						switch(model.getCurrBattlePhase())	{
						case NONE:
							break;
						
//						case ENEMYATTACK:
//							model.progressBattle();
//							break;
						default:
							if (time - getPauseTime() > 0.1)	{	
								model.progressBattlePhase();
								setPauseTime();
								break;
							}
						}
					}
				});
				
				switch (model.getBattleFlag())	{
				

				case NONE:
					model.updateLocationAndDirection();
						if (model.checkTransitionZones())	{
							view.changeBackground(model.newTown);
							model.newTown = Town.PALLET;
							model = remakeModel(Town.PALLET, model.enteredZone);
						}
					view.updateAll(model.playerX, model.playerY, model.getBattleFlag(), model.getEnemies(), model.player);
					view.drawTransitionZones(model.getTransitionZones());
					setPauseTime();
					break;
					
				default:
					
					switch (model.getCurrBattlePhase())	{
					
					case INTRO:
						view.BattleAnimation();
						System.out.println("Finished Drawing Battle Animation");
						break;
						
					case ENEMYATTACK:
						model.updateBattle(model.player, model.currEnemy);
						
					default:
						model.updateLocationAndDirection();
						view.update(model.getPlayerX(), model.getPlayerY(), model.mewTwoX, model.mewTwoY, model.getBattleFlag(), model.getSelectedAttack(), model.currEnemy, model.getPlayer());
						checkBattleFlag();
						checkBattlePhase();
						view.drawBattleDialog(model.getSavedAttack());
						if (model.getBattleFlag() == Battle.DURING && model.getCurrBattlePhase() == BattlePhase.USERATTACK)	{
							view.underLineAttack(model.getSelectedAttackInt());
						}	
					}
				}
				
				//If a battle has ended, the controller is informed and tells the model and view to reset their enums to NONE
				if (model.getNeedReset())	{
					model.setBattleFlag(Battle.NONE);
					model.setCurrBattlePhase(BattlePhase.NONE);
					view.setBattleFlag(Battle.NONE);
					view.setCurrBattlePhase(BattlePhase.NONE);
					model.setNeedReset(false);
				}
				
				
				// If no more enemies have health, then the tutorial ends
				if (model.checkEnemies())	{
					view.gc.setFont(new Font(100));
					view.gc.fillText("Thanks For Playing", 300, 300);
					view.gc.setFont(new Font(24));
				}
				
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			}
		}.start();
		stage.show();
	}
	
	public void checkBattleFlag()	{
		 if (this.view.getBattleFlag() != this.model.getBattleFlag())	{
			// if (this.view.getBattleFlag() == Battle.NONE)	{
				 this.model.setBattleFlag(this.view.getBattleFlag());
			 //}
		 }
	}
	// First stage of view isnt told to model right away
	public void checkBattlePhase()	{
		if (this.view.getCurrBattlePhase() != this.model.getCurrBattlePhase())	{
			if (this.model.getCurrBattlePhase() == BattlePhase.NONE)	{
				this.model.setCurrBattlePhase(this.view.getCurrBattlePhase());
			}
			else	{
				this.view.setCurrBattlePhase(this.model.getCurrBattlePhase());
			}
		}
	}
	
	public void setPauseTime()	{
		this.pauseTime = (System.nanoTime()- this.startNanoTime)/1E9;
	}
	
	public double getPauseTime()	{
		return this.pauseTime;
	}
	
	
	// Assuming the player is the only important attribute from the model
	public Model remakeModel(Town town, TransitionZone tz)	{
		Model temp = new Model(town, tz);
		temp.player.currHealth = model.player.currHealth;
		temp.transitions = model.transitions;
		model = null;
		return temp;
	}
}
