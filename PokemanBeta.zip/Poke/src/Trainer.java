import java.util.Collection;

public class Trainer extends NPC {
	Collection<Pokeman> party;
	
	
	public Trainer(String name, String dest, String msg, int xloc, int yloc, Collection<Pokeman> party)	{
		super(name, dest, msg, xloc, yloc);
		this.party = party;	
	}
}
