
public enum Town {
	PALLET(), VIRIDIAN();
}
