public class NPC {
	private String name;
	private String dest;
	private int xloc;
	private int yloc;
	private String msg;
	
	public NPC(String name, String dest, String msg, int xloc, int yloc)	{
		this.name = name;
		this.dest = dest;
		this.msg = msg;
		this.xloc = xloc;
		this.yloc = yloc;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDest() {
		return dest;
	}

	public void setDest(String dest) {
		this.dest = dest;
	}

	public int getXloc() {
		return xloc;
	}

	public void setXloc(int xloc) {
		this.xloc = xloc;
	}

	public int getYloc() {
		return yloc;
	}

	public void setYloc(int yloc) {
		this.yloc = yloc;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
}
