
public class HealingItem extends Item{
	private int healAmt;
	public HealingItem(int healAmt)	{
		this.healAmt = healAmt;
	}
	
	public int getHealAmt()	{
		return this.healAmt;
	}
}
