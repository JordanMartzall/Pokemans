import java.util.ArrayList;
import java.util.Collection;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class View {
	//graphics vars
	double canvasWidth;
	double canvasHeight;
	int imgWidth = 40;
	int imgHeight = 35;
	Font arial = new Font(24);
	private double rectlength;
	private double rectheight;
	private double rectX = 0;
	private double rectY = 0;
	private double rectBoundX;
	private double rectBoundY;
	
	// Image vars
	Image background = createImage("Pokemon_RBY_PalletTown.png");
	Image player = createImage("pokeYellow.png");
	Image wildPokemon = createImage("pokeYellow.png");
	Image enszer = createImage("enszer.png");
	
	// View vars
	Stage stage;
	Scene scene;
	Group root;
	GraphicsContext gc;
	
	//Battle vars
	final int enemyX = 850;
	final int enemyY = 50;
	final int friendlyPokeX = 100;
	final int friendlyPokeY = 500;
	
	
	// Box constants
	final int enemyYTopBox = 100;
	final int enemyYBotBox = 250;
	final int enemyXLeftBox = 250;
	final int enemyXRightBox = 750;
	
	final int UserYTopBox = 500;
	final int UserYBotBox = 650;
	final int UserXLeftBox = 250;
	final int UserXRightBox = 750;
	
	final int userAtt1x = 300;
	final int userAtt1y = 550;
	final int userAtt2x = 550;
	final int userAtt2y = 550;
	final int userAtt3x = 300;
	final int userAtt3y = 625;
	final int userAtt4x = 550;
	final int userAtt4y = 625;
	

	final int enemyAtt1x = 300;
	final int enemyAtt1y = 150;
	final int enemyAtt2x = 550;
	final int enemyAtt2y = 150;
	final int enemyAtt3x = 300;
	final int enemyAtt3y = 200;
	final int enemyAtt4x = 550;
	final int enemyAtt4y = 200;
	
	//Health Box Constants
	final int enemyYTopHealth = 75;
	final int enemyYBottomHealth = 100;
	
	final int userYTopHealth = 475;
	final int userYBottomHealth = 500;
	
	
	/**
	 *bars to indicate if the currHealth/maxHealth percentages are in correct regime
	 */
	final double redBar = 0.2;
	final double yellowBar = 0.5;
	final double greenBar = 1;
	
	int friendlyPokeCurrX = 1100;
	int enemyPokeCurrX = 0;
	Battle battleFlag = Battle.NONE;
	BattlePhase currPhase = BattlePhase.NONE;
	Direction currDirection = Direction.RIGHT;
	
	// Battle Messages
	final String EnemyBeginBattleMsg = "Prepare for Battle";
	final String EnemyEndBattleMsg = "You won";
	final int EnemyMsgX = 400;
	final int EnemyMsgY = 350;
	
	// Inventory Button
	Button bag = new Button("Inventory");
	boolean inBag = false;
	
	public View(Stage stage)	{
		this.stage = stage;
		this.root = new Group();
		this.scene = new Scene(root);
		this.canvasHeight = (int)(background.getHeight()*2.5);
		this.canvasWidth = (int)(background.getWidth()*4);
		this.rectlength = canvasWidth/20;
		this.rectheight = canvasHeight/20;
		this.rectBoundX = this.canvasWidth;
		this.rectBoundY = this.canvasHeight;
		Canvas canvas = new Canvas(canvasWidth, canvasHeight);
        root.getChildren().addAll(canvas);
        gc = canvas.getGraphicsContext2D();
        gc.setFont(arial);
	
        // Button insertion
	        bag.setLayoutX(10);
	        bag.setLayoutY(10);
	        bag.setPrefSize(100,80);
	        bag.setOnAction(value -> { 
	        	System.out.println("Pushed Button"); inBag = true; });
	       root.getChildren().add(bag);
        
	}

//	public void update(int playerX, int playerY, int mewTwoX, int mewTwoY, Battle battleFlag, String currAttack, int mewTwoHealth, Pokeman userPokeman)	{
//		this.battleFlag = battleFlag;
//		switch (battleFlag)	{
//		
//		case NONE:
//			gc.clearRect(0, 0, this.canvasWidth, this.canvasHeight);
//			gc.drawImage(background,  0, 0,this.canvasWidth,this.canvasHeight);
//			gc.drawImage(wildPokemon, 7.4*imgWidth, (22*imgHeight), imgWidth+20, imgHeight+30, mewTwoX, mewTwoY, 70 , 70);
//			gc.drawImage(player, 10, 22, imgWidth, imgHeight, playerX, playerY, 50, 50);
//		break;
//		
//		case TRIGGERED:
//			beginBattle();
//			break;
//		
//		case DURING:
//			drawBattle(mewTwoHealth, userPokeman);
//			break;
//		}
//	}
	public void updateAll(int playerX, int playerY, Battle battleFlag, Collection<Pokeman> collection, Pokeman playerPoke)	{
		this.battleFlag = battleFlag;
		switch (battleFlag)	{
		
		case NONE:
			gc.clearRect(0, 0, this.canvasWidth, this.canvasHeight);
			gc.drawImage(background,  0, 0,this.canvasWidth,this.canvasHeight);
			gc.drawImage(player, 10, 22, imgWidth, imgHeight, playerX, playerY, 50, 50);
			for (Pokeman enemy: collection)	{
				//gc.drawImage(wildPokemon, 7.4*imgWidth, (22*imgHeight), imgWidth+20, imgHeight+30, enemy.xloc, enemy.yloc, 70 , 70);
				gc.drawImage(enszer, 0,0,302,447, enemy.xloc, enemy.yloc, 70 , 70);
			}
		break;
		
		default:
			gc.clearRect(0, 0, this.canvasWidth, this.canvasHeight);
			gc.drawImage(background,  0, 0,this.canvasWidth,this.canvasHeight);
			gc.drawImage(player, 10, 22, imgWidth, imgHeight, playerX, playerY, 50, 50);
		}
	}
	
	public void update(int playerX, int playerY, int mewTwoX, int mewTwoY, Battle battleFlag, Attack attack, Pokeman enemy, Pokeman userPokeman)	{
		this.battleFlag = battleFlag;
		switch (battleFlag)	{
		
		case NONE:
			gc.clearRect(0, 0, this.canvasWidth, this.canvasHeight);
			gc.drawImage(background,  0, 0,this.canvasWidth,this.canvasHeight);
			gc.drawImage(enszer,0,0, 302, 447, mewTwoX, mewTwoY, 70 , 70);
		//	gc.drawImage(wildPokemon, 7.4*imgWidth, (22*imgHeight), imgWidth+20, imgHeight+30, mewTwoX, mewTwoY, 70 , 70);
			gc.drawImage(player, 10, 22, imgWidth, imgHeight, playerX, playerY, 50, 50);
		break;
		
		case TRIGGERED:
			beginBattle();
			gc.fillText(EnemyBeginBattleMsg, EnemyMsgX , EnemyMsgY);
			break;
		
		case DURING:
			resetBattleBeginning();
			drawBattle(enemy, userPokeman);
			break;
			
		case END:
			drawBattle(enemy, userPokeman);
			gc.fillText(EnemyEndBattleMsg, EnemyMsgX, EnemyMsgY);
		}
	}
	
	public void setStage()	{
		stage.setScene(scene);
	}

	public Image createImage(String dir)	{
		Image img = new Image(dir);
		return img;
	}
	
	public void drawBattle(Pokeman enemy, Pokeman userPokeman)	{
		gc.clearRect(0, 0,  this.canvasWidth, this.canvasHeight);
		gc.drawImage(wildPokemon, 7.4*imgWidth, (22*imgHeight), imgWidth+20, imgHeight+30, enemyX, enemyY, 200 , 200);
		//gc.drawImage(enszer, 0,0,302,447, enemyX, enemyY, 200 , 200);
		gc.drawImage(player, 10, 22, imgWidth, imgHeight, friendlyPokeX, friendlyPokeY, 100, 100);
		drawUserHealth(userPokeman);
		drawEnemyHealth(enemy);
		drawEnemyOptions(enemy);
		drawUserOptions(userPokeman);
	}
 
	public void beginBattle()	{
		if (friendlyPokeCurrX > friendlyPokeX) {
			friendlyPokeCurrX -= 50;
		}
		if (enemyPokeCurrX < enemyX)	{
			enemyPokeCurrX += 50;
		}
		else {
			setBattleFlag(Battle.DURING);
			setCurrBattlePhase(BattlePhase.USERATTACK);
		}
		gc.clearRect(0, 0,  this.canvasWidth, this.canvasHeight);
		gc.drawImage(enszer, 0,0,302,447, enemyPokeCurrX, enemyY, 200 , 200);
		//gc.drawImage(wildPokemon, 7.4*imgWidth, (22*imgHeight), imgWidth+20, imgHeight+30, enemyPokeCurrX, enemyY, 200 , 200);
		gc.drawImage(player, 10, 22, imgWidth, imgHeight, friendlyPokeCurrX, friendlyPokeY, 100, 100);
	}
	
	public void drawEnemyOptions(Pokeman enemy)	{
		gc.setFill(Color.BLACK);
		gc.strokeRect(enemyXLeftBox, enemyYTopBox,  enemyXRightBox-enemyXLeftBox, enemyYBotBox-enemyYTopBox);
		gc.fillText(enemy.attack1.toString(), enemyAtt1x, enemyAtt1y);
		gc.fillText(enemy.attack2.toString(), enemyAtt2x, enemyAtt2y);
		gc.fillText(enemy.attack3.toString(), enemyAtt3x, enemyAtt3y);
		gc.fillText(enemy.attack4.toString(), enemyAtt4x, enemyAtt4y);
		
		
	}
	
	public void drawUserOptions(Pokeman player)	{
		gc.setFill(Color.BLACK);
		gc.strokeRect(UserXLeftBox, UserYTopBox, UserXRightBox-UserXLeftBox, UserYBotBox-UserYTopBox);
		gc.fillText(player.attack1.toString(), userAtt1x, userAtt1y);
		gc.fillText(player.attack2.toString(), userAtt2x, userAtt2y);
		gc.fillText(player.attack3.toString(), userAtt3x, userAtt3y);
		gc.fillText(player.attack4.toString(), userAtt4x, userAtt4y);
		
		
	}
	
	public void setBattleFlag(Battle battleFlag)	{
		this.battleFlag = battleFlag;
	}

	public Battle getBattleFlag() {
		return this.battleFlag;
	}
	
	public void drawEnemyHealth(Pokeman enemy)	{
		gc.strokeRect(enemyXLeftBox, enemyYTopHealth, enemyXRightBox-enemyXLeftBox, enemyYBottomHealth - enemyYTopHealth);
		double xWidth = calcHealthPercent(enemy)*(enemyXRightBox-enemyXLeftBox);
		gc.fillRect(enemyXLeftBox, enemyYTopHealth, xWidth, enemyYBottomHealth - enemyYTopHealth);
	}
	
	public void drawUserHealth(Pokeman p1)	{
		gc.strokeRect(UserXLeftBox, userYTopHealth, UserXRightBox-UserXLeftBox, userYBottomHealth - userYTopHealth);
		double xWidth = calcHealthPercent(p1)*(UserXRightBox-UserXLeftBox);
		gc.fillRect(UserXLeftBox, userYTopHealth, xWidth, (userYBottomHealth - userYTopHealth));
	}
	
	public double calcHealthPercent(Pokeman p1)	{
		double percentage = p1.currHealth/p1.maxHealth;
		if (percentage > yellowBar)	{
			gc.setFill(Color.GREEN);
		}
		else if (percentage > redBar)	{
			gc.setFill(Color.YELLOW);
		}
		else	{
			gc.setFill(Color.RED);
		}
		return percentage;
	}
	
	
	public void underLineAttack(int attackInt)	{
		switch (attackInt)	{
		case 1: 
			gc.fillRect(userAtt1x, userAtt1y, 50, 1);
			break;
		case 2:
			gc.fillRect(userAtt2x, userAtt2y, 50,1);
			break;
		case 3:
			gc.fillRect(userAtt3x, userAtt3y, 50, 1);
			break;
		case 4:
			gc.fillRect(userAtt4x, userAtt4y, 50, 1);
			break;
		default :
			break;
		}
	}
	
	public void resetBattleBeginning()	{
		friendlyPokeCurrX = 1100;
		enemyPokeCurrX = 0;
	}
	
	public void drawTransitionZones(Collection<TransitionZone> collection)	{
		for (TransitionZone tz : collection)	{
			gc.strokeRect(tz.left, tz.top, tz.right-tz.left, tz.bottom-tz.top);
		}
	}
	
	public void changeBackground(Town town)	{
		if (town == Town.PALLET)	{
			this.background = createImage("Pokemon_RBY_PalletTown.png");
		}
		else if (town == Town.VIRIDIAN)	{
			this.background = createImage("viridian.gif");
		}
	}
	
	public void setCurrBattlePhase(BattlePhase currPhase)	{
		this.currPhase = currPhase;
	}
	
	public BattlePhase getCurrBattlePhase()	{
		return this.currPhase;
	}
	
	public void drawBattleDialog(Attack att)	{
		switch (getCurrBattlePhase())	{
		
		case NONE:
			break;
		case USERATTACK:
			gc.fillText("Select an Attack", EnemyMsgX, EnemyMsgY);
			break;
		case USERMOVE:
			gc.fillText("You chose " + att.name, EnemyMsgX, EnemyMsgY);
			break;
		case ENEMYATTACK:
			gc.fillText("Enemy is Selecting an Attack", EnemyMsgX, EnemyMsgY);
			break;
		case ENEMYMOVE:
			gc.fillText("Enemy used " + att.name, EnemyMsgX, EnemyMsgY);
			break;
		case ENEMYPHRASE:
			gc.fillText(this.EnemyEndBattleMsg,EnemyMsgX, EnemyMsgY);
			break;
		default:
			break;
		}
	}
	
	public void BattleAnimation()	{
		System.out.println("rectX: " + rectX);
		System.out.println("rectY: " + rectY);
		System.out.println("width: " + rectBoundX);
		System.out.println("heigth: " + rectBoundY);
		System.out.println("Direction: " + currDirection);
		gc.setFill(Color.BLACK);
		switch(this.currDirection)	{
		
		case RIGHT:
			gc.fillRect(rectX, rectY, rectlength, rectheight);
			//System.out.println();
			//rectX += rectlength;
			if (rectX + rectlength >= rectBoundX)	{
				progressDirection();
				//rectY += rectlength;
			}
		//	else	{
				rectX += rectlength;
			//}
			break;
	
		case DOWN:
			gc.fillRect(rectX, rectY, rectheight, rectlength);
			//rectY += rectlength;
			if (rectY + rectlength >= rectBoundY)	{
				progressDirection();
				//rectX -= rectlength;
			}
			//else {
				rectY += rectlength;
			//}
			break;
			
		case LEFT:
			gc.fillRect(rectX-(2*rectlength), rectY, rectlength, rectheight);
			//rectX -= rectlength;
			if (rectX - rectlength <= 0)	{
				progressDirection();
				//rectY -= rectlength;
			}
			//else {
				rectX -= rectlength;
			//}
			break;
		
		case UP:
			gc.fillRect(rectX, rectY+ 2*rectlength, rectheight, rectlength);
		//	rectY -= rectlength;
			if (rectY - rectlength <= 0)	{
				progressDirection();
				//rectX += rectlength;
			}
		//	else 	{
				rectY -= rectlength;
		//	}
			break;
		}
		//gc.clearRect(0, 0,  canvasWidth, canvasHeight);
	}
		
		public void progressDirection()	{
			switch (currDirection)	{
			
			case RIGHT:
				this.currDirection = Direction.DOWN;
				this.rectBoundX -= rectheight;
				break;
			case DOWN:
				this.currDirection = Direction.LEFT;
				this.rectBoundY -= rectheight;
				break;
			
			case LEFT:
				this.currDirection = Direction.UP;
				this.rectBoundX -= rectheight;
				break;
			case UP:
				this.currDirection = Direction.RIGHT;
				this.rectBoundY -= rectheight;
				break;
			
			default:
				break;
			}
		}
}
