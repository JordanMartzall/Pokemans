
public enum BattlePhase {
	NONE(), INTRO(), USERATTACK(), USERMOVE(), ENEMYATTACK(), ENEMYMOVE(), ENEMYPHRASE();
}
