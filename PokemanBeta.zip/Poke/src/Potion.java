
public class Potion extends HealingItem {
	final private static int potionHeal = 20;
	
	public Potion()	{
		super(potionHeal);
	}
	
}
