
public class TransitionZone {
	int left;
	int right;
	int top;
	int bottom;
	Town entranceOf;
	
	// Southern Box
	final int SleftX = 550;
	final int SrightX = 650;
	final int StopY = 630;
	final int SbottomY = 730;
	
	//Western Box
	final int WleftX = 0;
	final int WrightX = 100;
	final int WtopY = 300;
	final int WbottomY = 400;
	
	//Northern Box
	final int NleftX = 550;
	final int NrightX = 650;
	final int NtopY = 0;
	final int NbottomY = 100;
	
	//Eastern Box
	final int EleftX = 1150;
	final int ErightX = 1250;
	final int EtopY = 300;
	final int EbottomY = 400;
	
	public TransitionZone(int left, int right, int top, int bottom)	{
		this.left = left;
		this.right = right;
		this.top = top;
		this.bottom = bottom;
	}
	
	public TransitionZone()	{
		this.left = 0;
		this.right = 0;
		this.top = 0;
		this.bottom = 0;
	}
	
	
	// Maybe call the constructor wihtin here to use the Factory Design Pattern
	public void topZone()	{
		this.left = NleftX;
		this.right = NrightX;
		this.top = NtopY;
		this.bottom = NbottomY;
	}
	
	public void bottomZone()	{
		this.left = SleftX;
		this.right = SrightX;
		this.top = StopY;
		this.bottom = SbottomY;
	}
	
	public void leftZone()	{
		this.left = EleftX;
		this.right = ErightX;
		this.top = EtopY;
		this.bottom = EbottomY;
	}
	
	public void rightZone()	{
		this.left = WleftX;
		this.right = WrightX;
		this.top = WtopY;
		this.bottom = WbottomY;
	}
	
	public void setEntranceZone(Town town)	{
		this.entranceOf = town;
	}
	
}
