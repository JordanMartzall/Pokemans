
public enum Battle {
	TRIGGERED(), DURING(), END(), NONE(),
}
