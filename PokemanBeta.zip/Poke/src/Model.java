import java.util.Collection;
import java.util.Iterator;
import java.util.ArrayList;


public class Model {
	int playerX;
	int playerY;
	int velocity;
	int xMod;
	int yMod;
	
	int mewTwoX = 1000;
	int mewTwoY = 200;
	
	// Pokeman enemies collection
	Collection<Pokeman> enemies;
	Iterator<Pokeman> enemyIterator;
	int collisionRadius = 40;
	
	// NPC collection
	Collection<NPC> npcs;
	Iterator<NPC> npcsIterator;
	
	
	Battle battleFlag = Battle.NONE;
	boolean needReset = false;
	
	final Attack tackle = new Attack("tackle", 6, 10, "NULL");
	final Attack growl = new Attack("growl", 0, 10, "Enemy defense is lowered");
	final Attack vineWhip = new Attack("vine whip", 7, 8, "NULL");
	final Attack absorb = new Attack("absorb", 4, 8, "User health is replenished");
	
	final Attack psychic = new Attack("psychic", 9, 8, "NULL");
	final Attack calmMind = new Attack("calm mind" , 0, 10, "User sp. att. and sp. def. is increased");
	final Attack recover = new Attack("recover", 0,10, "User health is replenished");
	final Attack confusion = new Attack("confusion", 6, 10, "May cause confusion");
	
	
	final Pokeman player = new Pokeman("bulbasaur", tackle, growl, vineWhip, absorb, 160, 160);
	final Pokeman mewTwo = new Pokeman("mewtwo", confusion, calmMind, psychic, recover, 190, 190);
	final Pokeman mewTwo2 = new Pokeman("mew2", confusion, calmMind, psychic, recover, 190, 190);
	final Pokeman mewTwo3 = new Pokeman("mew3", confusion, calmMind, psychic, recover, 190, 190);
	// Null attack to be called as default
	final Attack nul = new Attack("null" , 0,0 ,"Null");
	
	//Check for input of new attack
	boolean yourMove = true;
	boolean moveSelected = false;
	private Attack selectedAttack = nul;
	private Attack savedAttack = nul;
	int selectedAttackInt = 1;
	
	// Variable for current EnemyPokeman
	Pokeman currEnemy;
	
	// Zone tranisionTesting
		Collection<TransitionZone> transitions;
		Town newTown = Town.VIRIDIAN;
		TransitionZone enteredZone;
		
	// Battle Phase Enum
		private BattlePhase currPhase = BattlePhase.NONE;
	
	// Potion Singleton
		public HealingItem potion = new Potion();
		
	public Model(int playerX, int playerY)	{
		this.playerX = playerX;
		this.playerY = playerY;
		this.xMod = 1;
		this.yMod = 1;
		this.velocity = 20;
		
		//Making the enemy Collection
		this.enemies = new ArrayList<Pokeman>();
		this.enemies.add(mewTwo);
		this.enemies.add(mewTwo2);
		enemyIterator = enemies.iterator();
		
		//Making the NPC collection
		this.npcs = new ArrayList<NPC>();
		
		
		// Creating town zone transitions
		 TransitionZone westZone = new TransitionZone();
	     TransitionZone eastZone = new TransitionZone();
	     TransitionZone northZone = new TransitionZone();
	     TransitionZone southZone = new TransitionZone();
		westZone.leftZone();
		westZone.setEntranceZone(Town.VIRIDIAN);
		eastZone.rightZone();
		westZone.setEntranceZone(Town.VIRIDIAN);
		northZone.topZone();
		northZone.setEntranceZone(Town.VIRIDIAN);
		southZone.bottomZone();
		southZone.setEntranceZone(Town.VIRIDIAN);
		this.transitions = new ArrayList<TransitionZone>();
		this.transitions.add(southZone);
		this.transitions.add(northZone);
		this.transitions.add(eastZone);
		this.transitions.add(westZone);
		Iterator<TransitionZone> transIt = transitions.iterator();
		
	}
	
	public Model(Town town, TransitionZone tz)	{
		// for north box
		if (tz.top == 0)	{
			this.playerX = tz.left;
			this.playerY = tz.EbottomY+ 50;
		}
		//for south box
		else if (tz.bottom == 730)	{
			this.playerX = tz.left;
			this.playerY = tz.EtopY - 50;
		}
		// for west box
		else if (tz.left == 0)	{
			this.playerX = tz.right+ 50;
			this.playerY = tz.EbottomY;
			}
		// for east box
		else if (tz.right == 1250)	{
			this.playerX = tz.left - 50;
			this.playerY = tz.bottom;
		}
		this.xMod = 1;
		this.yMod = 1;
		this.velocity = 20;
		this.enemies = new ArrayList<Pokeman>();
		enemies.add(mewTwo3);
		//Iterator<TransitionZone> transIt = transitions.iterator();
	}
	
	public void updateLocationAndDirection()	{
		switch (this.battleFlag)	{
		
		case NONE:
			this.playerX += this.xMod*this.velocity;
			this.playerY += this.yMod*this.velocity;
			setxMod(0);
			setyMod(0);
			collisionDetectionAll(enemies, npcs);
			break;
		
		case TRIGGERED:
			break;
			
		case DURING:
		//	battleOrganizer(player, mewTwo);
			break;
			
		case END:
			
			break;
		}	
		
	}
	
	public void setxMod(int xMod)	{
		this.xMod = xMod;
	}

	public void setyMod(int yMod)	{
		this.yMod = yMod;
	}
	
	public int getPlayerX()	{
		return this.playerX;
	}
	
	public int getPlayerY()	{
		return this.playerY;
	}
	
	public void collisionDetection(Pokeman enemy)	{
		int xLeft = enemy.xloc;
		int xRight = xLeft + collisionRadius;
		int yTop = enemy.yloc;
		int yBottom = yTop+ collisionRadius;
		if ((this.playerX > xLeft && this.playerX < xRight) && (this.playerY > yTop && this.playerY < yBottom))	{
			interact(enemy);
		}
	}
	
	public void collisionDetectionAll(Collection<Pokeman> enemies, Collection<NPC> npcs)	{
		for (Pokeman enemy : enemies)	{
			collisionDetection(enemy);
		}
	}
	public void setBattleFlag(Battle battleFlag)	{
		this.battleFlag = battleFlag;	
	}
	
	public Battle getBattleFlag()	{
		return this.battleFlag;
	}
	
	
	public Battle progressBattle()	{
		switch (getBattleFlag())	{
			
		case NONE:
			setBattleFlag(Battle.TRIGGERED);
			return getBattleFlag();
			
		case TRIGGERED:
			setBattleFlag(Battle.DURING);
			return getBattleFlag();
			
		case DURING:
			setBattleFlag(Battle.END);
			return getBattleFlag();
		
		case END:
			setBattleFlag(Battle.NONE);
			return getBattleFlag();
			
		default:
			setBattleFlag(Battle.NONE);
			return getBattleFlag();
		}
	}
	
	public BattlePhase progressBattlePhase()	{
		//System.out.println("CurrBattle Phase Before Advancing: " + getCurrBattlePhase());
		switch(getCurrBattlePhase())	{
		
		case NONE:
			setCurrBattlePhase(BattlePhase.USERATTACK);
			break;
			
		case INTRO:
			setCurrBattlePhase(BattlePhase.USERATTACK);
			break;
		case USERATTACK:
			setCurrBattlePhase(BattlePhase.USERMOVE);
			break;
		case USERMOVE:
			setCurrBattlePhase(BattlePhase.ENEMYATTACK);
			break;
		case ENEMYATTACK:
			setCurrBattlePhase(BattlePhase.ENEMYMOVE);
			break;
		case ENEMYMOVE:
			setCurrBattlePhase(BattlePhase.USERATTACK);
			break;
		case ENEMYPHRASE:
			setCurrBattlePhase(BattlePhase.NONE);
			break;
		}
		return getCurrBattlePhase();
	}
	
	public BattlePhase getCurrBattlePhase()	{
		return this.currPhase;
	}
	
	public void setCurrBattlePhase(BattlePhase currPhase)	{
		this.currPhase = currPhase;
	}
	
	
	public Pokeman getPlayer()	{
		return this.player;
	}
	
//	public Attack chooseAttack(int choice, Pokeman poke)	{
//		switch (choice)	{
//		
//		case 1:
//			setSelectedAttack(poke.attack1);
//			setMoveSelected(true);
//			return selectedAttack;
//			
//		case 2:
//			setSelectedAttack(poke.attack2);
//			setMoveSelected(true);
//			return selectedAttack;
//		case 3:
//			setSelectedAttack(poke.attack3);
//			setMoveSelected(true);
//			return selectedAttack;
//			
//		case 4:
//			setSelectedAttack(poke.attack4);
//			setMoveSelected(true);
//			return selectedAttack;
//		default:
//			return nul;
//		
//		}
//	}
	
	/**
	 * Second attempt at a choose Attack method. Should be given an order by the controller from arrow keys.
	 * Each arrow key input will select an attack. This method will not use an attack.
	 * Up == 1, 	down == 2, 		left == 3, 	right == 4
	 * Calls selectAttack which returns an Attack
	 */
	public Attack selectAttackInt(int input, Pokeman p1)	{
		
		switch (getSelectedAttackInt())	{
			
		case 1:
			if (input == 2)	{
				setSelectedAttackInt(3);
			}
			else if (input == 4)	{
				setSelectedAttackInt(2);
			}
			break;
		case 2:
			if (input == 2)	{
				setSelectedAttackInt(4);
			}
			else if (input == 3)	{
				setSelectedAttackInt(1);
			}
			break;
		case 3:
			if (input == 1)	{
				setSelectedAttackInt(1);
			}
			else if (input == 4)	{
				setSelectedAttackInt(4);
			}
			break;
		case 4:
			if (input == 1)	{
				setSelectedAttackInt(2);
			}
			else if(input == 3)	{
				setSelectedAttackInt(3);
			}
			break;
		default:
			break;
		}
		return selectAttack(getSelectedAttackInt(), p1);
	}
	
	public Attack selectAttack(int attInt, Pokeman p1)	{
		switch(attInt)	{
		
		case 1:
			setSelectedAttack(p1.attack1);
			return p1.attack1;
		case 2:
			setSelectedAttack(p1.attack2);
			return p1.attack2;
		case 3:
			setSelectedAttack(p1.attack3);
			return p1.attack3;
		case 4:
			setSelectedAttack(p1.attack4);
			return p1.attack4;
		default :
			return nul;
		}
		
	}
	
	/**
	 * 
	 * @param att
	 * @param attacker
	 * @param recipient
	 */
	
	
	// May be an issue that the last saved attack will transfer to a different cycle
	public void useAttack(Attack att, Pokeman attacker, Pokeman recipient)	{
		if (getYourMove())	{
			if (getSelectedAttack() != nul)	{
				if (getCurrBattlePhase() == BattlePhase.USERMOVE || getCurrBattlePhase() == BattlePhase.ENEMYATTACK)	{
					recipient.currHealth -= 10*att.damage;
					setSelectedAttack(nul);
					setSavedAttack(att);
					if (recipient.currHealth <= 0)	{
						progressBattle();
						setNeedReset(true);
						//setCurrBattlePhase(BattlePhase.NONE);
						enemies.remove(recipient);
					}
				}
			}
		}
	}
	
	public void setYourMove(boolean yourMove)	{
		this.yourMove = yourMove;
	}
	
	public boolean getYourMove()	{
		return this.yourMove;
	}
	
	/**
	 * Determines who's turn it is, if they have used a move and what move they have chosen
	 */
//	public void battleOrganizer(Pokeman player, Pokeman mewTwo)	{
//		if (getYourMove())	{
//			if (getMoveSelected())	{
//				useAttack(getSelectedAttack(), player, mewTwo);
//				setYourMove(false);
//				setMoveSelected(false);
//				setSelectedAttack(nul);
//			}
//		}
//		
//		else	{
//			useAttack(chooseAttack(1, mewTwo), mewTwo, player);
//			setYourMove(true);
//			setMoveSelected(true);
//		}
//	}

	public boolean getMoveSelected() {
		return this.moveSelected;
	}
	
	public void setMoveSelected(boolean moveSelected)	{
		this.moveSelected = moveSelected;
	}
	
	public void setSelectedAttack(Attack selectedAttack)	{
		this.selectedAttack = selectedAttack;
	}
	
	public Attack getSelectedAttack()	{
		return this.selectedAttack;
	}
	
	public int getSelectedAttackInt()	{
		return this.selectedAttackInt;
	}
	
	public void setSelectedAttackInt(int selAttInt)	{
		this.selectedAttackInt = selAttInt;
	}

	public Collection<Pokeman> getEnemies()	{
		return this.enemies;
	}
	
	public boolean checkEnemies()	{
		if (this.enemies.isEmpty())	{
			return true;
		}
		else	{
			return false;
		}
	}
	
	public Collection<TransitionZone> getTransitionZones()	{
		return this.transitions;
	}
	
	public boolean checkTransitionZones()	{
		for (TransitionZone tz : transitions)	{
			if ((playerX > tz.left && playerX < tz.right) && (playerY > tz.top && playerY < tz.bottom))	{
				enteredZone = tz;
				return true;
			}
		}
		return false;
	}
	
	public void setNeedReset(boolean needReset)	{
		this.needReset = needReset;
	}
	
	public boolean getNeedReset()	{
		return this.needReset;
	}
	
	public Attack getSavedAttack()	{
		return this.savedAttack;
	}
	
	public void setSavedAttack(Attack savedAttack)	{
		this.savedAttack = savedAttack;
	}
	
	public void updateBattle(Pokeman userPoke, Pokeman enemy)	{
		if (getBattleFlag() == Battle.DURING)	{
			if (getCurrBattlePhase() == BattlePhase.ENEMYATTACK)	{
				useAttack(selectAttack(enemy.seed.nextInt(4) + 1, enemy), enemy, userPoke);
				progressBattlePhase();
			}
		}
	}
	
	public void useItem(HealingItem item, Pokeman pokeman)	{
		if (item.getHealAmt() + pokeman.currHealth >= pokeman.maxHealth)	{
			pokeman.currHealth = pokeman.maxHealth;
		}
		else	{
			pokeman.currHealth += item.getHealAmt();
		}
		//progressBattle();
	}
	
	public void interact(NPC npc)	{
		
	}
	
	public void interact(Trainer trainer)	{
		
	}
	
	public void interact(Pokeman pokeman)	{
		progressBattle();
		this.currEnemy = pokeman;
	}
}

